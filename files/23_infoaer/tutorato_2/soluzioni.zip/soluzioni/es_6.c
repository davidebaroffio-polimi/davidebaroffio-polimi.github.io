#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char nome[32];          // nome del prodotto
    int prezzo;             // prezzo del prodotto
} t_prodotto;

typedef struct {
    t_prodotto *prodotti;   // lista di prodotti
    int np;                 // numero prodotti
} t_whishlist;

t_whishlist carica_dati(char* nomefile);

void stampa_oggetti_acquistabili(t_whishlist whishlist, int budget);

void stampa_whishlist(t_whishlist whishlist) {
    printf("Ecco la whishlist:\n");
    for (int i=0; i<whishlist.np; i++) {
        printf("%d: %s %d\n", i, whishlist.prodotti[i].nome, whishlist.prodotti[i].prezzo);
    }
}

int main() {
    t_whishlist whishlist;
    int budget;
    char nomefile[128];

    scanf("%s", nomefile);
    scanf("%d", &budget);

    whishlist = carica_dati(nomefile);
    stampa_whishlist(whishlist);
    stampa_oggetti_acquistabili(whishlist, budget);
}

t_whishlist carica_dati(char* nomefile) {
    t_whishlist res;
    t_prodotto *prodotti;
    int prodotti_size;
    FILE *dati;

    dati = fopen(nomefile, "r");
    if (dati == NULL) {
        fprintf(stderr, "Errore aprendo il file!\n");
        exit(0);
    }

    prodotti_size = 100;
    res.prodotti = malloc(sizeof(t_prodotto) * prodotti_size);
    res.np = 0;
    while (fscanf(dati, "%s %d", res.prodotti[res.np].nome, &res.prodotti[res.np].prezzo) != EOF) {
        res.np++;
        if (res.np >= prodotti_size) {
            prodotti = malloc(sizeof(t_prodotto) * (prodotti_size + 100)); // increase the memory size
            memcpy(prodotti, res.prodotti, sizeof(t_prodotto) * prodotti_size);
            free(res.prodotti);
            res.prodotti = prodotti;
        }
    }
    fclose(dati);
    return res;
}

int calcola_prezzo(t_whishlist whishlist) {
    int res = 0;
    for (int i=0; i<whishlist.np; i++) {
        res += whishlist.prodotti[i].prezzo;
    }
    return res;
}

// somma 1 al numero binario rappresentato dall'array di interi `bin`
void somma_1_binario(int* bin, int len) {
    int carry = 1;
    for (int i=len-1; i>=0; i--) {
        if (carry == 0) {
            break;
        }
        else if (bin[i] == 0) {
            bin[i] = 1;
            break;
        }
        else if (bin[i] == 1) {
            bin[i] = 0;
        }
    }
}

int conta_elementi_non_nulli(int* bin, int len) {
    int res = 0;
    for (int i=0; i<len; i++) {
        if (bin[i] != 0) {
            res++;
        }
    }
    return res;
}

int power(int a, int b) {
    int res = 1;
    for (int i=0; i<b; i++) {
        res = res * a;
    }
    return res;
}

void stampa_oggetti_acquistabili(t_whishlist whishlist, int budget) {
    t_whishlist candidate_whishlist;
    t_prodotto *prodotti;
    int *candidate_selettore;
    int *selettore;
    int candidate_idx;
    int candidate_prezzo;
    int max = 0; // tiene il massimo del prezzo trovato finora

    // inizializza il selettore a zero
    selettore = malloc(sizeof(int) * whishlist.np);
    candidate_selettore = malloc(sizeof(int) * whishlist.np);
    for (int i=0; i<whishlist.np; i++) {
        selettore[i] = 0;
    }

    for (int j=0; j<power(2, whishlist.np); j++) {
        somma_1_binario(selettore, whishlist.np); // aggiungi 1 al selettore corrente

        candidate_whishlist.np = conta_elementi_non_nulli(selettore, whishlist.np);
        prodotti = malloc(sizeof(t_prodotto) * candidate_whishlist.np);

        // riempi la whishlist candidata
        candidate_idx = 0;;
        for (int k=0; k<whishlist.np; k++) {
            if (selettore[k] == 1) {
                memcpy(&prodotti[candidate_idx], &whishlist.prodotti[k], sizeof(t_prodotto));
                candidate_idx++;
            }
        }

        candidate_whishlist.prodotti = prodotti;

        // controlla il costo della whishlist candidata
        candidate_prezzo = calcola_prezzo(candidate_whishlist);
        if (candidate_prezzo <= budget && candidate_prezzo > max) {
            memcpy(candidate_selettore, selettore, sizeof(int) * whishlist.np);
            max = candidate_prezzo;
        }
        
        free(prodotti);
    } 
    
    for (int x=0; x<whishlist.np; x++) {
        if (candidate_selettore[x] == 1) {
            printf("%d\n", x);
        }
    }

    free(selettore);
    free(candidate_selettore);
    free(whishlist.prodotti);
}