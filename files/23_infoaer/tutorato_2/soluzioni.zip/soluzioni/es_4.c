#include <stdio.h>

int base12();

int main() {
	printf("%d\n", base12());
}

int lunghezzastr(char* buf) {
    int res = 0;
    for (int i = 0; buf[i] != '\x00'; i++) {
        res++;
    }

    return res;
}

int base12() {
    char buf[9] = {0};
    int res = 0, sign;
    
    scanf("%8s", buf);

    if (buf[0] == '-') {
        buf[0] = '0'; // reset the most significant digit
        sign = -1;
    }
    else {
        sign = 1;
    }

    printf("%s\n", buf);

    for (int i = 0; i<lunghezzastr(buf); i++) {
        if (buf[i] >= '0' && buf[i] <= '9') {
            res = res * 12 + (buf[i] - '0');
        }
        else if (buf[i] == 'a') {
            res = res * 12 + 10;
        }
        else if (buf[i] == 'b') {
            res = res * 12 + 11;
        }
        // Il più piccolo che si può rappresentare: -bbbbbbb
        // Il più grande che non si può rappresentare: -bbbbbbb - 1 = -10000000 (che sarebbe -12^7)
        else return - 12 * 12 * 12 * 12 *
                    12 * 12 * 12;           // -12^7
    }

    res = res * sign;

    return res;
}

