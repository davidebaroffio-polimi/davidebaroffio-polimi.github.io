#include <stdio.h>
#include <string.h>

#define N 8

int metagramma(char m[][N], int l);

int main() {
	int n=0, i;
	char s[N+1];
	scanf("%d", &n);
	char matrice[n][N];

	for(i = 0; i<n; i++) {
		scanf("%s", s);
		strncpy(matrice[i],s,N);
	}

	printf("%d\n",metagramma(matrice,n));

	return 0;
}

int conta_caratteri_diversi(char* s1, char* s2) {
    int res = 0; 
    
    for (int i=0; s1[i] != '\x00'; i++) {
        if (s1[i] != s2[i]) {
            res++;
        }
    }

    return res;
}

int metagramma(char m[][N], int l) {
    for (int i=0; i<l-1; i++) {
        if (conta_caratteri_diversi(m[i], m[i+1]) != 1) {
            return i+1;
        }
    }

    return l;
}