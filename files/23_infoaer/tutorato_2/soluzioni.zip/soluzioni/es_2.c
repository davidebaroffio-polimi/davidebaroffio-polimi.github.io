#include <stdio.h>
#include <stdlib.h>

int *leggi_matrice(int r, int c){
    int *m=malloc(sizeof(int)*r*c);
    for(int i=0; i<r; i++)
        for(int j=0; j<c; j++)
            scanf("%d", &m[i*c+j]);
    return m;
}

void stampa_matrice(int *m, int r, int c){
    for(int i=0; i<r; i++) {
        for(int j=0; j<c; j++)
            printf("%d ", m[i*c+j]);
        printf("\n");
    }
}

int trova2x2sommapari(int *m, int r, int c);

int main(){
    int r, c;
    scanf("%d %d\n", &r, &c);
    int *m=leggi_matrice(r,c);
    stampa_matrice(m,r,c);
    printf("%d\n", trova2x2sommapari(m, r, c));
    free(m);
}

int fattoriale(int num) {
    int res = 1;
    for (int i=1; i<=num; i++) {
        res = res * i;
    }
    return res;
}

int trova_duplicati(int *array, int len) {
    for (int i=0; i<len-1; i++) {
        for (int j=i; j<len; j++) {
            if (array[i] == array[j]) {
                return 1;
            }
        }
    }
    return 0;
}

int trova2x2sommapari(int *m, int r, int c) {
    // check all the combinations without repetitions, in total they are (n! / ((n-R)! R!)), with n=r*c and R=4
    printf("%d\n", fattoriale(r*c));

    int num_combinations = fattoriale(r*c) / (fattoriale(r*c - 4) * fattoriale(4));
    int *somme = malloc(num_combinations*sizeof(int));
    int num_elems = 0;

    for (int i=0; i<r-1; i++) {
        for (int j=i+1; j<r; j++) {

            for (int x=0; x<c-1; x++) {
                for (int y=0; y<c; y++) {
                    somme[num_elems] = m[i*c+x] + m[i*c+y] + m[j*c+x] + m[j*c+y];
                    num_elems++;
                    if (trova_duplicati(somme, num_elems) == 1) {
                        return 1;
                    }
                }
            }

        }
    }

    return 0;
}