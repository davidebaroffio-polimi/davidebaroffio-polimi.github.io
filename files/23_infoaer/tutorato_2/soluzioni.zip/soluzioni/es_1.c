#include <stdio.h>
#include <stdlib.h>

void leggi_caratteri_safe(char *buf, int len) {
    for (int i=0; i<len; i++) {
        buf[i] = getc(stdin);
    }
}

void leggi_caratteri_unsafe(char *buf, int len) {
    scanf("%s", buf);
}

int main() {
    int len, idx;
    int moda = 0;
    char* buf;
    char occorrenze[26] = {0};

    scanf("%d\n", &len);

    buf = malloc((len + 1) * sizeof(char));
    leggi_caratteri_safe(buf, len);

    printf("%s\n", buf);

    // trova le occorrenze
    for (int i=0; i<len; i++) {
        idx = buf[i] - 'a';
        occorrenze[idx]++;
    } 

    // trova la moda (il massimo numero di occorrenze)
    for (int j=0; j<26; j++) {
        if (occorrenze[j] > moda) {
            moda = occorrenze[j];
        }
    }

    printf("%d\n", moda);

    for (int k=0; k<26; k++) {
        if (occorrenze[k] == moda) {
            printf("%c\n", 'a'+k);
        }
    }

    free(buf);

    return 0;
}