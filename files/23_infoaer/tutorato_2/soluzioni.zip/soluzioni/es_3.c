#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char nome[32];   // nome della porta
    char input[32];  // componente 1, input
    char output[32]; // componente 2, output
    int numero_riga; // numero di linea nel file
} t_porta;

typedef struct {
    char nome[32];      // nome del componente
    char operatore[32]; // operatore
    int numero_riga;    // numero di linea nel file
} t_componente;

typedef struct {
    t_componente *componenti; // array dinamico di componenti
    t_porta *porte;           // array dinamico di porte
    int np;                   // lunghezza dell'array delle porte
    int nc;                   // lunghezza dell'array dei componenti
} t_circuito;

// Dichiarazioni anticipate
t_circuito carica_dati(char *nomefile);

void stampa_errori(t_circuito c);

// Funzioni di supporto
void stampa_circuito(t_circuito c){
    if (c.nc != 0) {
        for (int i = 0; i < c.nc; i++)
            printf("%s ", c.componenti[i].nome);
        printf("\n");
    }

    if (c.np != 0) {
        for (int i = 0; i < c.np; i++)
            printf("%s ", c.porte[i].nome);
        printf("\n");
    }
}

int main(){
    char nomef[128];
    scanf("%s", nomef);
    t_circuito c = carica_dati(nomef);
    printf("componenti = %d\n", c.nc);
    printf("porte = %d\n", c.np);
    printf("circuito:\n");
    stampa_circuito(c);
    printf("errori:\n");
    stampa_errori(c);
}

int lunghezzastr(char* s) {
    int i = 0;
    while (s[i] != '\x00') {
        i++;
    }
    return i;
}

int comparastringhe(char* s1, char* s2) {
    for (int i=0; s1[i] != '\x00' && s2[i] != '\x00'; i++) {
        if (s1[i] != s2[i]) {
            return 0;
        }
    }
    return 1;
}

t_circuito carica_dati(char *nomefile) {
    t_circuito res;
    t_componente *componenti;
    t_porta *porte;
    FILE *dati;
    int size_componenti = 100, size_porte = 100;
    int riga = 0;
    char s[32];

    res.nc = 0;
    res.np = 0;

    res.componenti = malloc(sizeof(t_componente) * 100);
    res.porte = malloc(sizeof(t_porta) * 100);

    dati = fopen(nomefile, "r");

    while (fscanf(dati, "%s", s) != EOF) {
        if (comparastringhe(s, "componente") == 1) {

            // allocazione dinamica della memoria
            if (res.nc + 1 >= size_componenti) {
                componenti = malloc(sizeof(t_componente) * (size_componenti + 100));
                memcpy(componenti, res.componenti, sizeof(t_componente) * size_componenti);
                free(res.componenti);
                res.componenti = componenti;
                size_componenti = size_componenti + 100;
            }

            fscanf(dati, "%s %s", res.componenti[res.nc].nome, res.componenti[res.nc].operatore);

            res.componenti[res.nc].numero_riga = riga;

            res.nc++;
        }
        else if (comparastringhe(s, "porta") == 1) {
            
            // allocazione dinamica della memoria
            if (res.np + 1 >= size_porte) {
                porte = malloc(sizeof(t_porta) * (size_porte + 100));
                memcpy(porte, res.porte, sizeof(t_porta) * size_porte);
                free(res.porte);
                res.porte = porte;
                size_porte = size_porte + 100;
            }

            fscanf(dati, "%s %s %s", res.porte[res.np].nome, res.porte[res.np].input, res.porte[res.np].output);

            res.porte[res.np].numero_riga = riga;

            res.np++;
        }
        else {
            // altri casi non considerati in questo esercizio
        }

        riga++;
    }
     
    fclose(dati);
    return res;
}

void stampa_errori(t_circuito c) {
    int input_trovato; 
    int output_trovato;

    for (int i=0; i<c.np; i++) {
        input_trovato = 0;
        output_trovato = 0;
        for (int j=0; j<c.nc; j++) { 
            // controlliamo che input e output della porta siano nei componenti del circuito
            if (comparastringhe(c.porte[i].input, c.componenti[j].nome) == 1) {
                input_trovato = c.porte[i].numero_riga > c.componenti[j].numero_riga;
            }
            if (comparastringhe(c.porte[i].output, c.componenti[j].nome) == 1) {
                output_trovato = c.porte[i].numero_riga > c.componenti[j].numero_riga;
            }
        }

        if (!input_trovato || !output_trovato) { // se non abbiamo trovato I/O della porta abbiamo un errore
            printf("%s\n", c.porte[i].nome);
        }
    }
}
