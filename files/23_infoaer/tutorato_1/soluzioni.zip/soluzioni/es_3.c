#include <stdio.h>
#include <stdlib.h>
typedef enum {
    FORZA, AGILITA,VELOCITA, RESISTENZA
} caratteristiche_t;

typedef struct {
    char nome[32];
    unsigned short caratteristiche[4]; 
    /* NOTA: Si possono usare i valori descritti da caratteristiche_t 
    per indicizzare questo array */
} persona_t;

typedef struct {
    persona_t *elementi; /* Contiene i dati degli atleti */
    unsigned numero; /* Numero di atleti nel campo elementi */
} squadra_t;

squadra_t carica_dati(char* nome_file);

int verifica(squadra_t s);

int esiste_squadra(squadra_t s);

int main() {
    char nomef[100];
    scanf("%s", nomef);
    squadra_t s = carica_dati(nomef);
    printf("%d\n", s.numero);
    if (s.numero > 1 && s.numero < 5) 
    printf("%d\n", verifica(s));
    if (s.numero > 5) 
    printf("%d\n", esiste_squadra(s));
    return 0;
}

squadra_t carica_dati(char* nome_file) {
    squadra_t res;
    int forza, agilita, velocita, resistenza;
    int i=0, j=0, size = 100;
    char nome[32];
    persona_t *persona;
    persona_t *elementi_tmp;
    persona_t elementi[100];
    FILE* dati;

    dati = fopen(nome_file, "r");
    if (dati == NULL) {
        fprintf(stderr, "Error in fopen.\n");
        exit(0);
    }

    res.elementi = elementi;
    res.numero = 0;
    while (fscanf(dati, "%s %d %d %d %d\n", nome, &forza, &agilita, &velocita, &resistenza) != EOF) {
        
        // sequenza di controllo opzionale (solo se ci sono 100 atleti o più)
        res.numero++;
        if(res.numero >= size) { // alloca altre 100 persone
            elementi_tmp = malloc(sizeof(persona_t*) * (size + 100));
            for (int j=0; j<size; j++) {
                elementi_tmp[j] = res.elementi[j];
            }
            res.elementi = elementi_tmp;
        }

        persona = malloc(sizeof(persona_t));

        // copia il nome
        i=0;
        while (nome[i] != '\x00') {
            persona->nome[i] = nome[i];
            i++;
        }
        // copia le caratteristiche
        persona->caratteristiche[FORZA] = forza;
        persona->caratteristiche[AGILITA] = agilita;
        persona->caratteristiche[VELOCITA] = velocita;
        persona->caratteristiche[RESISTENZA] = resistenza;

        // aggiungi la persona alla lista di elementi
        res.elementi[res.numero-1] = *persona;
    }
    fclose(dati);
    return res;
} 

int verifica(squadra_t s) {
    int i, j, k;
    unsigned short min[4], max[4];

    min[FORZA] = s.elementi[0].caratteristiche[FORZA];
    min[AGILITA] = s.elementi[0].caratteristiche[AGILITA];
    min[VELOCITA] = s.elementi[0].caratteristiche[VELOCITA];
    min[RESISTENZA] = s.elementi[0].caratteristiche[RESISTENZA];

    max[FORZA] = s.elementi[0].caratteristiche[FORZA];
    max[AGILITA] = s.elementi[0].caratteristiche[AGILITA];
    max[VELOCITA] = s.elementi[0].caratteristiche[VELOCITA];
    max[RESISTENZA] = s.elementi[0].caratteristiche[RESISTENZA];

    for (i = 1; i < s.numero; i++) {
        for (j = 0; j<4; j++) {
            if (s.elementi[i].caratteristiche[j] > max[j]) {
                max[j] = s.elementi[i].caratteristiche[j];
            }
            if (s.elementi[i].caratteristiche[j] < min[j]) {
                min[j] = s.elementi[i].caratteristiche[j];
            }
        }
    }

    for (k = 0; k<4; k++) {
        if (max[k] - min[k] > 5) {
            return 0;
        }
    }
    return 1;
}

int esiste_squadra(squadra_t s) {
    int i, j, k, m, n;
    persona_t tentativo_elementi[5];
    squadra_t tentativo_sq;
    tentativo_sq.elementi = tentativo_elementi;
    tentativo_sq.numero = 5;
    for (i = 0; i+4 < s.numero; i++) {
        for (j = i+1; j+3 < s.numero; j++) {
            for (k = j+1; k+2 < s.numero; k++) {
                for (m = k+1; m+1 < s.numero; m++) {
                    for (n = m+1; n < s.numero; n++) {
                        tentativo_elementi[0] = s.elementi[i];
                        tentativo_elementi[1] = s.elementi[j];
                        tentativo_elementi[2] = s.elementi[k];
                        tentativo_elementi[3] = s.elementi[m];
                        tentativo_elementi[4] = s.elementi[n];
                        if (verifica(tentativo_sq) == 1) return 1;
                    }
                }
            }
        }
    }
    return 0;
}