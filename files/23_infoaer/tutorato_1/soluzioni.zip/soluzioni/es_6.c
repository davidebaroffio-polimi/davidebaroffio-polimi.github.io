#include <stdio.h>

#define BUF_LEN 1024

float calcolaMediana(int *occorrenze_original, int len) {
    int tmp, num_zeri=0;
    int min, min_i;
    float mediana;
    int occorrenze[len];

    // copia le occorrenze
    for (int i=0; i<len; i++) {
        occorrenze[i] = occorrenze_original[i];
        if (occorrenze_original[i] == 0) {
            num_zeri++;
        }
    }

    // ordina le occorrenze
    for (int i=0; i<len; i++) {
        min = occorrenze[i];
        min_i = i;
        for (int j=i; j<len; j++) {
            if (occorrenze[j] < min) {
                min = occorrenze[j];
                min_i = j;
            }
        }
        tmp = occorrenze[i];
        occorrenze[i] = occorrenze[min_i];
        occorrenze[min_i] = tmp;
    }

    // Ora l'array delle occorrenze inizia con num_zeri volte il numero 0, e poi ha le
    // occorrenze non nulle. A noi interessano solo queste ultime.

    // Se c'è un numero dispari di occorrenze non-nulle, prendi la metà (approssimata)
    if ((len - num_zeri) % 2 == 1) {
        mediana = occorrenze[num_zeri + (len-num_zeri)/2];
    }
    else { // altrimenti calcola la media tra la metà e la metà meno uno
        mediana = (occorrenze[num_zeri + (len-num_zeri)/2] + occorrenze[num_zeri + (len-num_zeri)/2 - 1]) / 2.0;
    }
    return mediana;
}

int main() {
    char buf[BUF_LEN] = {0};
    int occorrenze[26] = {0};
    float mediana;

    // Ricevi l'unput
    scanf("%[a-zA-Z]s", buf);
    // popola l'array delle occorrenze
    for (int i = 0; i<BUF_LEN && buf[i] >= 'a' && buf[i] <= 'z'; i++) {
        occorrenze[buf[i] - 'a']++;
    }

    // calcola la mediana
    mediana = calcolaMediana(occorrenze, 26);
    printf("Mediana: %f\n\n", mediana);

    // stampa le occorrenze di ogni carattere
    for (int i=0; i<26; i++) {
        if (occorrenze[i] > 0) {
            printf("%c: %d\n", 'a' + i, occorrenze[i]);
        }
    }

    printf("\n");

    // stampa la stringa di caratteri con occorrenze > mediana
    for (int i=0; i<26; i++) {
        if (occorrenze[i] > mediana) {
            printf("%c", 'a' + i);
        }
    }
    printf("\n");
}