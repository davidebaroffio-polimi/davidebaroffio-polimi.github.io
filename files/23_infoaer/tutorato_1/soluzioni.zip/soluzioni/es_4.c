#include <stdio.h>
#include <stdlib.h>

int base12toInt(char *numBase12) {
    int res = 0; // accumulatore
    char currChar;
    for (int i=0; i<8; i++) {
        currChar = numBase12[i];
        if (currChar == 0) {
            break; // abbiamo raggiunto la fine della stringa
        }
        if (currChar >= '0' && currChar <= '9') {
            res = (res * 12) + (currChar - '0');
        }
        else if (currChar == 'a') {
            res = (res * 12) + 10;
        }
        else if (currChar == 'b') {
            res = (res * 12) + 11;
        }
        else {
            return -1;
        }
    }
    return res;
}

int lunghezzaNumeroInBase2(int num) {
    int res = 0; // accumulatore
    do {
        num = num / 2;
        res++;
    } while (num != 0);
    return res;
}

int lunghezzaNumeroInBase16(int num) {
    int res = 0; // accumulatore
    do {
        num = num / 16;
        res++;
    } while (num != 0);
    return res;
}

void stampaNumeroInEsadecimale(int num) {
    int lung, carry, i = 1;;
    char *result;

    lung = lunghezzaNumeroInBase16(num);
    result = malloc((lung+1)*sizeof(char));
    result[lung] = 0;

    do {
        carry = num % 16;
        num = num / 16;
        if (carry <= 9) {
            result[lung-i] = '0' + carry;
        }
        else {
            result[lung-i] = 'a' + carry - 10;
        }
        i++;
    } while (num != 0);
    printf("%s\n", result);
    free(result);
}

int main() {
    int numBase10, lung;
    char numBase12[9] = {0};

    scanf("%8s", numBase12);

    numBase10 = base12toInt(numBase12);
    if (numBase10 == -1) {
        printf("-1\n");
    }
    else {
        lung = lunghezzaNumeroInBase2(numBase10);
        printf("Lunghezza in base 2: %d\n", lung);

        printf("Rappresentazione in esadecimale: ");
        stampaNumeroInEsadecimale(numBase10);
    }

    return 0;
}

