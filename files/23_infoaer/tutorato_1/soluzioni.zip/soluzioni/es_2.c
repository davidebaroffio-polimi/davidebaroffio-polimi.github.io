#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int biscarto(char* a, char* b, char* c);
int biscarto_alt(char* a, char* b, char* c);

int main() {
    char a[128], b[128], c[128];
    scanf("%s %s %s", a,b,c);
    printf("%d\n", biscarto(a,b,c));
    printf("%d\n", biscarto_alt(a,b,c));
    return 0;
} // end main

int test_biscarto(char *a, char* b, char* c, int candidate, int scartolen) {
    int i;
    int idxa=candidate;
    int idxb=strlen(c);

    // prendi l'indice della prima differenza tra a e c
    for (i = 0; i<candidate; i++) {
        if (a[i] != c[i]) {
            idxa = i;
            break;
        }
    }

    // prendi l'indice della prima differenza tra b e la seconda parte di c
    for (i = 0; i<=strlen(c) - candidate; i++) {
        if (b[i] != c[candidate + i]) {
            idxb = i;
            break;
        }
    }

    // controlla che lo scarto sia uguale tra a e b
    for (i = 0; i<scartolen; i++) {
        if (a[idxa + i] != b[idxb + i]) {
            return -1;
        }
    }

    // controlla che la sottostringa successiva allo scarto in a sia in c
    for (i = idxa; i<candidate; i++) {
        if (a[i + scartolen] != c[i]) {
            return -1;
        }
    }
    // controlla che la sottostringa successiva allo scarto in b sia in c
    for (i = idxb; i<strlen(c) - candidate; i++) {
        if (b[i + scartolen] != c[candidate + i]) {
            return -1;
        }
    }
    return 1;
}

void trovaScarto(char* a, char* b, int* idxa, int* idxb, int* len) {
    int tmp_len = 0;
    int k=0;
    for (int i = 0; i<strlen(a); i++) {
        for (int j = 0; j<strlen(b); j++) {
            if (a[i] == b[j]) {
                *idxa = i;
                *idxb = j;
                while (a[i+k] == b[j+k]) {
                    tmp_len++;
                    k++;
                }
                *len = tmp_len;
                return;
            }
        }
    }
    
}

/*
Questa soluzione (che è simile a quella proposta all'esame) però è limitata perché trova solo la prima sottostringa. Biscarti come:
aba / abc = abbc
aba / abc = babc 
Non vengono riconosciuti da questo metodo.
*/
int biscarto_alt(char* a, char* b, char* c) {
    // questa versione trova la sottostringa in comune tra a e b, la rimuove 
    // producendo a_ e b_ e controlla che la concatenazione c_ di a_ e b_ sia uguale a c

    int idxa, idxb, len, i, j; 
    trovaScarto(a, b, &idxa, &idxb, &len);
    char *c_;
    c_ = malloc(sizeof(char) * (strlen(a) + strlen(b) - len*2)); 

    // build c_
    i=0;
    for (j=0; j<strlen(a); j++) {
        if (j < idxa || j >= idxa + len) {
            c_[i] = a[j];
            i++;
        }
    }
    for (j=0; j<strlen(b); j++) {
        if (j < idxb || j > idxb + len) {
            c_[i] = b[j];
            i++;
        }
    }
    
    if (strcmp(c, c_) == 0) {
        return strlen(a) - len;
    }
    else return -1;
}

int biscarto(char* a, char* b, char* c) {
    for (int i = 0; i < strlen(c); i++) {
        for (int l = 1; l <= strlen(c) - i; l++) {
            if (test_biscarto(a, b, c, i, l) == 1) {
                return i;
            }
        }
    }
    return -1;
}