#include <stdio.h>
#include <stdlib.h>

#define N 4

// definiamo la matrice dell'esempio
int matrix_A[N][N] = {
    {1, 0, 0, 1},
    {0, 1, 0, 1},
    {1, 0, 1, 0},
    {1, 1, 0, 1}
};

void printMatrix(int matrix[N][N]) {
    printf("==========\n");
    for (int i=0; i<N; i++) {
        for (int j=0; j<N; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

void copyMatrix(int matrix[N][N], int res[N][N]) {
    for (int i=0; i<N; i++) {
        for (int j=0; j<N; j++) {
            res[i][j] = matrix[i][j];
        }
    }
}

int conta_adiacenti(int matrix[N][N], int i, int j) {
    int count = 0;
    int vicini = 0;

    for (int m = -1; m<=1; m++) {
        for (int n = -1; n<=1; n++) {
            if (i+m >= 0 && i+m < N && j+n >= 0 && j+n < N) {
                count = count + matrix[i+m][j+n];
                vicini++;
            }
        }
    }
    return count*2 >= vicini;
} 

void evolveMatrix(int matrix[N][N]) {
    int original_matrix[N][N];
    copyMatrix(matrix, original_matrix);

    for (int i=0; i<N; i++) {
        for (int j=0; j<N; j++) {
            matrix[i][j] = conta_adiacenti(original_matrix, i, j);
        }
    }
}

int main() {
    printf("Originale:\n");
    printMatrix(matrix_A);
    
    evolveMatrix(matrix_A);

    printf("\nEvolved:\n");
    printMatrix(matrix_A);
}