#include <stdio.h>
#include <stdlib.h>

int base7toInt(char *base7str) {
    int currNum = 0, res = 0;
    for (int i=0; base7str[i] != '\x00'; i++) {
        if (base7str[i] < '0' || base7str[i] > '6') {
            return -1;
        }
        else {
            currNum = base7str[i] - '0';
            res = res * 7 + currNum;
        }
    }
    return res;
}

int numBitsForC2(int num) {
    int res = 1;
    if (num == 0) return 1;
    else {
        while (num != 0) {
            res++;
            num = num/2;
        }
    }
    return res;
}

void printIntToCompl2(int num) {
    int size = numBitsForC2(num);
    int num_cpy = num;
    int carry = 1;
    char *buf = malloc((size + 1) * sizeof(char));

    if (num < 0) {
        num_cpy = -num;
    }

    for (int i = size-1; i >= 0; i--) {
        buf[i] = '0' + (num_cpy % 2);
        num_cpy = num_cpy/2;
    }
    buf[size] = '\x00';

    if (num < 0) {
        for (int j=size-1; j>=0; j--) {
            if (buf[j] == '0') {
                if (carry == 0) 
                    buf[j] = '1';
                else {
                    buf[j] = '0';
                    carry = 1;
                }
            }
            else if (buf[j] == '1') {
                if (carry == 0) 
                    buf[j] = '0';
                else {
                    buf[j] = '1';
                    carry = 0;
                }
            }
        }
    }
    printf("%s\n", buf);
    free(buf);
}

int main() {
    char s1[8], s2[8];
    int n1, n2;

    scanf("%8s %8s", s1, s2);

    n1 = base7toInt(s1);
    if (n1 == -1) {
        fprintf(stderr, "Errore 1\n");
        return 0;
    }

    n2 = base7toInt(s2);
    if (n2 == -1) {
        fprintf(stderr, "Errore 2\n");
        return 0;
    }

    printIntToCompl2(n1 - n2);
}